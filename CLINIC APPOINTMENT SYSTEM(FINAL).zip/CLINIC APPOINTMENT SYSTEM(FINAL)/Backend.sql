 CREATE TABLE ClinicPatient (
PatientID INT PRIMARY KEY IDENTITY,
Name VARCHAR(50),
Age INT,
Gender VARCHAR(50),
Contact VARCHAR(50),
Email VARCHAR(100),
Password VARCHAR(50)
);
INSERT INTO ClinicPatient (PatientID,Name, Age, Gender, Contact, Email, Password) 
VALUES
(1,'Hina Tariq', 42, 'Female', '(555) 123-4567', 'hinatariq@gmail.com', 'Hina123'),
(2,'Muhammad Hussain', 35, 'Male', '(555) 987-6543', 'm.hussain@gmail.com', 'Hussain123'),
(3,'Raiqa', 39, 'Female', '(555) 456-7890', 'raiqa@gmail.com', 'Raiqa123');
select * from clinicpatient;

CREATE TABLE ClinicDoctor (
DoctorID INT PRIMARY KEY IDENTITY,
Name VARCHAR(50),
Specialization VARCHAR(50),
Contact VARCHAR(50),
Availability VARCHAR(100)
);
INSERT INTO ClinicDoctor (DoctorID,Name, Specialization, Contact, Availability)
VALUES
(1,'Dr. Ali Ahmed', 'Cardiology', '0300-1234567', 'Mon-Fri 9:00 AM - 4:00 PM'),
(2,'Dr. Suqlain', 'Neurology', '0300-9876543', 'Mon-Wed 10:00 AM - 6:00 PM'),
(3,'Dr. Naila Waseem', 'Pediatrics', '0300-4567890', 'Mon-Fri 8:30 AM - 3:30 PM');
select * from clinicdoctor;

CREATE TABLE ClinicAdmin (
AdminID INT PRIMARY KEY,
Name VARCHAR(50),
Email VARCHAR(100),
Contact VARCHAR(50),
Role VARCHAR(50),
Password VARCHAR(50)
);
INSERT INTO ClinicAdmin (AdminID, Name, Email, Contact, Role, Password)
VALUES
(1, 'Immad Ali', 'immad@medicare.com', '(555) 123-4567', 'Super Admin', 'ADMIN1'),
(2, 'Muhammad Soban', 'soban@medicare.com', '(555) 987-6543', 'Admin', 'ADMIN2'),
(3, 'Nabiha Fatima', 'nabiha@medicare.com', '(555) 456-7890', 'Receptionist', 'ADMIN3');
select * from clinicadmin;

CREATE TABLE ClinicAppointment(
AppointmentID INT PRIMARY KEY IDENTITY,
PatientID INT,
DoctorID INT,
AppointmentDate DATE,
AppointmentTime VARCHAR(20),
Reason VARCHAR(255),
Status VARCHAR(20),
FOREIGN KEY (PatientID) REFERENCES ClinicPatient(PatientID),
FOREIGN KEY (DoctorID) REFERENCES ClinicDoctor(DoctorID)
);
INSERT INTO ClinicAppointment (AppointmentID, PatientID, DoctorID, AppointmentDate, AppointmentTime, Reason, Status)
VALUES
(1, 1, '2023-06-05', '10:30 AM', 'Heart checkup', 'Confirmed'),
(2, 2, '2023-06-06', '11:15 AM', 'Headache consultation', 'Pending'),
(3, 3, '2023-06-07', '2:00 PM', 'Child vaccination', 'Confirmed');
select * from clinicappointment;

CREATE TABLE ClinicFeedback (
FeedbackID INT PRIMARY KEY IDENTITY,
PatientID INT,
DoctorID INT,
AppointmentID INT,
FeedbackText VARCHAR(255),
Rating INT CHECK (Rating >= 1 AND Rating <= 5),
FOREIGN KEY (PatientID) REFERENCES ClinicPatient(PatientID),
FOREIGN KEY (DoctorID) REFERENCES ClinicDoctor(DoctorID),
FOREIGN KEY (AppointmentID) REFERENCES ClinicAppointment(AppointmentID)
);
INSERT INTO ClinicFeedback (PatientID, DoctorID, AppointmentID, FeedbackText, Rating)
VALUES
(1, 1, 1, 'Dr. Ali was very professional and explained everything clearly. Friendly staff.', 5),
(2, 2, 2, 'Good experience overall, but wait time was long. Dr. Hussain was helpful.', 4),
(3, 3, 3, 'Excellent pediatric care. Dr. Naila was patient and kind.', 5);
select * from clinicfeedback;

-------------------------------------------Patient Quries----------------------------------------------------
-- Register new patient
INSERT INTO ClinicPatient (Name, Age, Gender, Contact, Email, Password) 
VALUES ('Ibrahim', 20, 'Male', '000-123456', 'ibrahim@gmail.com', 'ibrahim123');

-- Get patient profile
SELECT * FROM ClinicPatient WHERE PatientID = 2;

--Update patient record
UPDATE ClinicPatient 
SET Name = ?, Age = ?, Gender = ?, Contact = ?, Email = ?
WHERE PatientID = ?;

--Delete patient records
DELETE FROM ClinicPatient WHERE PatientID = ?;

---------------------------------------Doctor Queries--------------------------------------------------------
--Add new doctor
INSERT INTO ClinicDoctor (DoctorID,Name, Specialization, Contact, Availability)
VALUES (4, 'Dr. Maria', 'Cardiology', '000-2437858', 'Mon-Fri 2:00 PM - 6:00 PM');

-- List all doctors
SELECT DoctorID, Name, Specialization, Contact, Availability 
FROM ClinicDoctor;

--Update Doctor 
UPDATE ClinicDoctor
SET Name = ?, Specialization = ?, Contact = ?, Availability = ?
WHERE DoctorID = ?;

--delete doctor record
Delete from clinicdoctor where doctorID=?;

----------------------------------------Appointment Queries--------------------------------------------------
-- Book appointment
INSERT INTO ClinicAppointment (PatientID, DoctorID, AppointmentDate, AppointmentTime, Reason, Status) 
VALUES (4,2 , '2025-06-12' , '5:00PM', 'Pending');

-- Get patient's appointments
SELECT AppointmentID, AppointmentDate, AppointmentTime, Status,Name AS DoctorName, Specialization
FROM ClinicAppointment a
JOIN ClinicDoctor d  ON a.DoctorID = d.DoctorID
WHERE PatientID = 3;

-- Update appointment status
UPDATE ClinicAppointment SET Status ='Confirmed' WHERE AppointmentID = 1;

-- Check time slot availability (NEW)
SELECT AppointmentID FROM ClinicAppointment 
WHERE DoctorID = 1 
  AND AppointmentDate = '2023-06-05' 
  AND AppointmentTime = '10:30AM';

  --Delete/ Update appointment
  UPDATE ClinicAppointment SET Status = 'Cancelled' WHERE AppointmentID = ?;
DELETE FROM ClinicAppointment WHERE AppointmentID = ?;

-- Get pending appointments
SELECT AppointmentID, AppointmentDate, AppointmentTime,p.Name AS PatientName, d.Name AS DoctorName
FROM ClinicAppointment a
JOIN ClinicPatient p ON a.PatientID = p.PatientID
JOIN ClinicDoctor d ON a.DoctorID = d.DoctorID
WHERE a.Status = 'Pending';

------------------------------------Feedback queries---------------------------------------------------------
-- Submit feedback
INSERT INTO ClinicFeedback 
(PatientID, DoctorID, AppointmentID, FeedbackText, Rating) 
VALUES (4,2,6 , 'Dr.Suqlain is an expert neurology doctor', 4);

------------------------------------Admin Queries-------------------------------------------------------
--Add new admin
INSERT INTO ClinicAdmin (AdminID, Name, Email, Contact, Role, Password) 
VALUES 
(1, 'Mirha Ali', 'mirha@medicare.com', '(233) 123-4567', 'Super Admin', 'ADMIN2');

--Update admin details
UPDATE ClinicAdmin 
SET 
    Name = 'Updated Name',
    Email = 'new_email@example.com',
    Contact = '03009876543',
    Role = 'Hospital Admin'
WHERE AdminID = 101;

--delete admin
DELETE FROM ClinicAdmin 
WHERE AdminID = 1;