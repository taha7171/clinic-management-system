<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all admins
if ($method === 'GET') {
    $stmt = $db->query("SELECT * FROM ClinicAdmin");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// POST: Create a new admin
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (
        !$data->Name || !$data->Email ||
        !$data->Contact || !$data->Role || !$data->Password
    ) {
        http_response_code(400);
        echo json_encode(["message" => "All fields are required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO ClinicAdmin (Name, Email, Contact, Role, Password)
        VALUES (?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $data->Name,
        $data->Email,
        $data->Contact,
        $data->Role,
        $data->Password
    ]);

    echo json_encode(["message" => $success ? "Admin added" : "Failed to add admin"]);
}

// PUT: Update an existing admin
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['AdminID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AdminID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE ClinicAdmin
        SET Name=?, Email=?, Contact=?, Role=?, Password=?
        WHERE AdminID=?
    ");

    $success = $stmt->execute([
        $data->Name,
        $data->Email,
        $data->Contact,
        $data->Role,
        $data->Password,
        $id
    ]);

    echo json_encode(["message" => $success ? "Admin updated" : "Failed to update admin"]);
}

// DELETE: Delete an admin
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['AdminID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AdminID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM ClinicAdmin WHERE AdminID = ?");
    $success = $stmt->execute([$id]);

    echo json_encode(["message" => $success ? "Admin deleted" : "Failed to delete admin"]);
}
?>
