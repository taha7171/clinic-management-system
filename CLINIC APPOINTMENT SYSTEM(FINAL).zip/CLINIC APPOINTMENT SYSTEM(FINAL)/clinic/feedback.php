<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all feedback with doctor and patient names
if ($method === 'GET') {
    $stmt = $db->query("
        SELECT f.*, 
               p.Name AS PatientName, 
               d.Name AS DoctorName, 
               a.AppointmentDate, 
               a.AppointmentTime
        FROM ClinicFeedback f
        JOIN ClinicPatient p ON f.PatientID = p.PatientID
        JOIN ClinicDoctor d ON f.DoctorID = d.DoctorID
        JOIN ClinicAppointment a ON f.AppointmentID = a.AppointmentID
    ");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// POST: Add new feedback
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (
        !$data->PatientID || !$data->DoctorID || !$data->AppointmentID ||
        !$data->FeedbackText || !$data->Rating
    ) {
        http_response_code(400);
        echo json_encode(["message" => "All fields are required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO ClinicFeedback (PatientID, DoctorID, AppointmentID, FeedbackText, Rating)
        VALUES (?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $data->PatientID,
        $data->DoctorID,
        $data->AppointmentID,
        $data->FeedbackText,
        $data->Rating
    ]);

    echo json_encode(["message" => $success ? "Feedback submitted" : "Failed to submit feedback"]);
}

// PUT: Update feedback text and rating
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['FeedbackID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing FeedbackID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE ClinicFeedback
        SET FeedbackText = ?, Rating = ?
        WHERE FeedbackID = ?
    ");

    $success = $stmt->execute([
        $data->FeedbackText,
        $data->Rating,
        $id
    ]);

    echo json_encode(["message" => $success ? "Feedback updated" : "Failed to update feedback"]);
}

// DELETE: Remove feedback entry
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['FeedbackID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing FeedbackID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM ClinicFeedback WHERE FeedbackID = ?");
    $success = $stmt->execute([$id]);

    echo json_encode(["message" => $success ? "Feedback deleted" : "Failed to delete feedback"]);
}
?>
