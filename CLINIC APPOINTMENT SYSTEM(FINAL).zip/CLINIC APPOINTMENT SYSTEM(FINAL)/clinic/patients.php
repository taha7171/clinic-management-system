<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

if (!$db) {
    http_response_code(500);
    echo json_encode(["message" => "Database connection failed"]);
    exit;
}

// GET: Retrieve all patients
if ($method === 'GET') {
    $stmt = $db->query("SELECT * FROM ClinicPatient");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// POST: Add new patient
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    if (!isset($data->Name, $data->Age, $data->Gender, $data->Contact, $data->Email, $data->Password)) {
        http_response_code(400);
        echo json_encode(["message" => "Missing required fields"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO ClinicPatient (Name, Age, Gender, Contact, Email, Password)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $success = $stmt->execute([
        $data->Name, $data->Age, $data->Gender,
        $data->Contact, $data->Email, $data->Password
    ]);
    echo json_encode(["message" => $success ? "Patient added" : "Failed to add patient"]);
}

// PUT: Update patient
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['PatientID'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing PatientID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));
    $stmt = $db->prepare("
        UPDATE ClinicPatient
        SET Name = ?, Age = ?, Gender = ?, Contact = ?, Email = ?, Password = ?
        WHERE PatientID = ?
    ");
    $success = $stmt->execute([
        $data->Name, $data->Age, $data->Gender,
        $data->Contact, $data->Email, $data->Password, $id
    ]);
    echo json_encode(["message" => $success ? "Patient updated" : "Failed to update patient"]);
}

// DELETE: Delete patient
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['PatientID'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing PatientID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM ClinicPatient WHERE PatientID = ?");
    $success = $stmt->execute([$id]);
    echo json_encode(["message" => $success ? "Patient deleted" : "Failed to delete patient"]);
}
?>

