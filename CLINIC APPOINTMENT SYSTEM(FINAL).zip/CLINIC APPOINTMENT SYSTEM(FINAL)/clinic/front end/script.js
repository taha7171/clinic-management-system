document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Form submission handlers
    const adminForm = document.getElementById('adminForm');
    if (adminForm) {
        adminForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Admin added successfully!');
            // Here you would typically send data to backend
            // Example: 
            // const formData = new FormData(adminForm);
            // fetch('/api/admins', { method: 'POST', body: formData })
            //     .then(response => response.json())
            //     .then(data => console.log(data));
        });
    }
    
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        patientForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Patient registered successfully!');
        });
    }
    
    const doctorForm = document.getElementById('doctorForm');
    if (doctorForm) {
        doctorForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Doctor added successfully!');
        });
    }
    
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Appointment scheduled successfully!');
        });
    }
    
    // Sample data for tables (in a real app, this would come from an API)
    const sampleAdmins = [
        { name: "David Miller", email: "david@medicare.com", phone: "(555) 123-4567", role: "Super Admin" },
        { name: "Jennifer Lee", email: "jennifer@medicare.com", phone: "(555) 987-6543", role: "Admin" },
        { name: "Mark Taylor", email: "mark@medicare.com", phone: "(555) 456-7890", role: "Receptionist" }
    ];
    
    // Function to populate admin table (example)
    function populateAdminTable() {
        const tableBody = document.querySelector('#admin table tbody');
        if (tableBody) {
            tableBody.innerHTML = '';
            sampleAdmins.forEach(admin => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${admin.name}</td>
                    <td>${admin.email}</td>
                    <td>${admin.phone}</td>
                    <td>${admin.role}</td>
                    <td>
                        <button class="btn-secondary edit-btn">Edit</button>
                        <button class="delete-btn">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
            
            // Add event listeners to buttons
            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    alert('Edit functionality would go here');
                });
            });
            
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (confirm('Are you sure you want to delete this admin?')) {
                        alert('Delete functionality would go here');
                    }
                });
            });
        }
    }
    
    // Initialize the page
    populateAdminTable();
});
// --- Main app and tabs logic ---
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Form submission handlers
    const adminForm = document.getElementById('adminForm');
    if (adminForm) {
        adminForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Admin added successfully!');
        });
    }
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        patientForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Patient registered successfully!');
        });
    }
    const doctorForm = document.getElementById('doctorForm');
    if (doctorForm) {
        doctorForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Doctor added successfully!');
        });
    }
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Appointment scheduled successfully!');
        });
    }

    // Sample data for tables (in a real app, this would come from an API)
    const sampleAdmins = [
        { name: "David Miller", email: "david@medicare.com", phone: "(555) 123-4567", role: "Super Admin" },
        { name: "Jennifer Lee", email: "jennifer@medicare.com", phone: "(555) 987-6543", role: "Admin" },
        { name: "Mark Taylor", email: "mark@medicare.com", phone: "(555) 456-7890", role: "Receptionist" }
    ];

    // Function to populate admin table (example)
    function populateAdminTable() {
        const tableBody = document.querySelector('#admin table tbody');
        if (tableBody) {
            tableBody.innerHTML = '';
            sampleAdmins.forEach(admin => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${admin.name}</td>
                    <td>${admin.email}</td>
                    <td>${admin.phone}</td>
                    <td>${admin.role}</td>
                    <td>
                        <button class="btn-secondary edit-btn">Edit</button>
                        <button class="delete-btn">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
            
            // Add event listeners to buttons
            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    alert('Edit functionality would go here');
                });
            });
            
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (confirm('Are you sure you want to delete this admin?')) {
                        alert('Delete functionality would go here');
                    }
                });
            });
        }
    }

    // Initialize the page
    populateAdminTable();

    // --- Patient Portal Functions START ---
    let currentPatient = null;

    function showLoginForm() {
      document.getElementById('patientLoginForm').style.display = 'block';
      document.getElementById('patientRegisterForm').style.display = 'none';
      document.getElementById('patientDashboard').style.display = 'none';
    }

    function showRegisterForm(event) {
      if (event) event.preventDefault();
      document.getElementById('patientLoginForm').style.display = 'none';
      document.getElementById('patientRegisterForm').style.display = 'block';
      document.getElementById('patientDashboard').style.display = 'none';
    }

    function showPatientDashboard() {
      document.getElementById('patientAuthForms').style.display = 'none';
      document.getElementById('patientDashboard').style.display = 'block';
    }

    // Sample patient data
    const patients = [
      {
        id: 1,
        name: "Test Patient",
        email: "patient@test.com",
        password: "test123",
        phone: "(555) 123-4567",
        appointments: [
          {
            id: 1,
            date: "2023-06-15",
            time: "10:30 AM",
            doctor: "Dr. Ali Ahmed",
            reason: "Annual Checkup",
            status: "confirmed"
          },
          {
            id: 2,
            date: "2023-06-20",
            time: "2:00 PM",
            doctor: "Dr. Naila Waseem",
            reason: "Follow-up",
            status: "pending"
          }
        ],
        medicalInfo: "Allergic to penicillin. No other known conditions."
      }
    ];

    function patientLogin(event) {
      event.preventDefault();
      const email = document.getElementById('patientEmail').value;
      const password = document.getElementById('patientPassword').value;
      
      const patient = patients.find(p => p.email === email && p.password === password);
      
      if (patient) {
        currentPatient = patient;
        document.getElementById('patientGreeting').textContent = patient.name;
        loadPatientData(patient);
        showPatientDashboard();
      } else {
        alert('Invalid email or password');
      }
    }

    function patientRegister(event) {
      event.preventDefault();
      const newPatient = {
        id: patients.length + 1,
        name: document.getElementById('patientName').value,
        email: document.getElementById('patientRegEmail').value,
        password: document.getElementById('patientRegPassword').value,
        phone: document.getElementById('patientPhone').value,
        appointments: [],
        medicalInfo: ""
      };
      
      patients.push(newPatient);
      alert('Registration successful! Please login.');
      showLoginForm();
    }

    function loadPatientData(patient) {
      // Load appointments
      const appointmentsList = document.getElementById('patientAppointmentsList');
      if (appointmentsList) {
        if (patient.appointments.length > 0) {
          appointmentsList.innerHTML = patient.appointments.map(appt => `
            <div class="appointment-item">
              <h6>${appt.doctor}</h6>
              <p>${appt.date} at ${appt.time}</p>
              <p>Reason: ${appt.reason}</p>
              <span class="appointment-status status-${appt.status}">${appt.status}</span>
            </div>
          `).join('');
        } else {
          appointmentsList.innerHTML = '<p>No appointments scheduled</p>';
        }
      }
      // Load medical info
      const medicalInfo = document.getElementById('patientMedicalInfo');
      if (medicalInfo) {
        medicalInfo.innerHTML = `<p>${patient.medicalInfo || 'No medical information available.'}</p>`;
      }
    }

    function patientLogout() {
      currentPatient = null;
      // Clear form fields
      document.getElementById('patientEmail').value = '';
      document.getElementById('patientPassword').value = '';
      document.getElementById('patientName').value = '';
      document.getElementById('patientRegEmail').value = '';
      document.getElementById('patientRegPassword').value = '';
      document.getElementById('patientPhone').value = '';
      
      // Show login form
      showLoginForm();
    }

    function showBookAppointmentForm() {
      alert('Appointment booking form would appear here in a full implementation');
    }

    // Patient portal button (header)
    const portalBtn = document.querySelector('.header-content button[onclick="togglePatientPortal()"]');
    if (portalBtn) {
      portalBtn.addEventListener('click', togglePatientPortal);
    }

    // Toggle Patient Portal Modal/Container
    function togglePatientPortal() {
        const portal = document.getElementById('patientPortalContainer');
        if (portal.style.display === 'none' || !portal.style.display) {
            portal.style.display = 'block';
            showLoginForm();
        } else {
            portal.style.display = 'none';
        }
    }
    window.togglePatientPortal = togglePatientPortal; // expose for button onclick

    function hidePatientPortal() {
        document.getElementById('patientPortalContainer').style.display = 'none';
    }
    window.hidePatientPortal = hidePatientPortal;

    // Register/login toggle links
    document.querySelectorAll('.form-switch a').forEach(link => {
      link.addEventListener('click', showRegisterForm);
    });

    // Patient Portal Modal logic
    const loginForm = document.getElementById('patientLoginForm');
    if (loginForm && loginForm.querySelector('button')) {
      loginForm.querySelector('button').addEventListener('click', patientLogin);
    }
    const registerForm = document.getElementById('patientRegisterForm');
    if (registerForm && registerForm.querySelector('button')) {
      registerForm.querySelector('button').addEventListener('click', patientRegister);
    }

    // Logout button
    const logoutBtn = document.querySelector('#patientDashboard button[onclick="patientLogout()"]');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', patientLogout);
    }

    // Book appointment button
    const bookApptBtn = document.querySelector('#patientDashboard button[onclick="showBookAppointmentForm()"]');
    if (bookApptBtn) {
      bookApptBtn.addEventListener('click', showBookAppointmentForm);
    }

    // Close button
    const closeBtn = document.querySelector('.close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', hidePatientPortal);
    }

    // Overlay click
    const overlay = document.querySelector('.patient-portal-overlay');
    if (overlay) {
      overlay.addEventListener('click', hidePatientPortal);
    }
    // --- Patient Portal Functions END ---
});