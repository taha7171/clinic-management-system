<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all doctors
if ($method === 'GET') {
    $stmt = $db->query("SELECT * FROM ClinicDoctor");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// POST: Create new doctor
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (
        !$data->Name || !$data->Specialization || !$data->Contact ||
        !$data->Email || !$data->LicenseNumber || !$data->Availability
    ) {
        http_response_code(400);
        echo json_encode(["message" => "All fields are required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO ClinicDoctor (Name, Specialization, Contact, Email, LicenseNumber, Availability)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $data->Name,
        $data->Specialization,
        $data->Contact,
        $data->Email,
        $data->LicenseNumber,
        $data->Availability
    ]);

    echo json_encode(["message" => $success ? "Doctor added" : "Failed to add doctor"]);
}

// PUT: Update doctor info by DoctorID
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['DoctorID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing DoctorID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE ClinicDoctor
        SET Name=?, Specialization=?, Contact=?, Availability=?
        WHERE DoctorID=?
    ");

    $success = $stmt->execute([
        $data->Name,
        $data->Specialization,
        $data->Contact,
        $data->Availability,
        $id
    ]);

    echo json_encode(["message" => $success ? "Doctor updated" : "Failed to update doctor"]);
}

// DELETE: Remove doctor by DoctorID
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['DoctorID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing DoctorID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM ClinicDoctor WHERE DoctorID = ?");
    $success = $stmt->execute([$id]);

    echo json_encode(["message" => $success ? "Doctor deleted" : "Failed to delete doctor"]);
}
?>
