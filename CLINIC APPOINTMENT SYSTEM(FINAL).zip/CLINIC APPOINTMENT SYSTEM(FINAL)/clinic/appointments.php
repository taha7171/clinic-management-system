<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all appointments
if ($method === 'GET') {
    $stmt = $db->query("
        SELECT a.*, p.Name AS PatientName, d.Name AS DoctorName
        FROM ClinicAppointment a
        JOIN ClinicPatient p ON a.PatientID = p.PatientID
        JOIN ClinicDoctor d ON a.DoctorID = d.DoctorID
    ");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// POST: Create a new appointment
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (
        !$data->PatientID || !$data->DoctorID || !$data->AppointmentDate ||
        !$data->AppointmentTime || !$data->Reason || !$data->Status
    ) {
        http_response_code(400);
        echo json_encode(["message" => "All fields are required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO ClinicAppointment (PatientID, DoctorID, AppointmentDate, AppointmentTime, Reason, Status)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $success = $stmt->execute([
        $data->PatientID,
        $data->DoctorID,
        $data->AppointmentDate,
        $data->AppointmentTime,
        $data->Reason,
        $data->Status
    ]);

    echo json_encode(["message" => $success ? "Appointment created" : "Failed to create appointment"]);
}

// PUT: Update appointment details
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['AppointmentID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AppointmentID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE ClinicAppointment
        SET PatientID = ?, DoctorID = ?, AppointmentDate = ?, AppointmentTime = ?, Reason = ?, Status = ?
        WHERE AppointmentID = ?
    ");

    $success = $stmt->execute([
        $data->PatientID,
        $data->DoctorID,
        $data->AppointmentDate,
        $data->AppointmentTime,
        $data->Reason,
        $data->Status,
        $id
    ]);

    echo json_encode(["message" => $success ? "Appointment updated" : "Failed to update appointment"]);
}

// DELETE: Delete appointment
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $id = $params['AppointmentID'] ?? null;

    if (!$id) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AppointmentID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM ClinicAppointment WHERE AppointmentID = ?");
    $success = $stmt->execute([$id]);

    echo json_encode(["message" => $success ? "Appointment deleted" : "Failed to delete appointment"]);
}
?>
